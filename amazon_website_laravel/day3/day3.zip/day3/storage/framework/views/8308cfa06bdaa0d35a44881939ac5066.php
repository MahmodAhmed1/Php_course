<?php $__env->startSection("title", "Categories"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Category: <?php echo e($category->name); ?></title>
</head>
<body>
    <h1>Category: <?php echo e($category->name); ?></h1>

    <h2>Products in this Category:</h2>
    <?php if($products->isEmpty()): ?>
        <p>No products found in this category.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->price); ?></td>
                
                <td><img src="<?php echo e(asset($product->image)); ?>" alt="Product Image" height="100"></td>
                <td>
                    <a href="/products/<?php echo e($product->id); ?>"><button class='editButton'>Show</button></a>


                    <a href="<?php echo e(route('products.edit',$product->id)); ?>"><button class='editpButton'>Edit</button></a>

                    <form action="products/<?php echo e($product->id); ?>/delete" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button class='deleteButton' type="submit" onclick="return confirm('Are you sure you want to delete this product?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
</body>
</html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/categories/show.blade.php ENDPATH**/ ?>