<?php $__env->startSection("title", "Contact Us"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Contact Us</h1>
        <p>If you have any questions, feel free to contact us using the information below:</p>

        <ul>
            <li>Email: contact@amazon.com</li>
            <li>Phone: 109-669-4106</li>
            <li>Address: Nasr City, Cairo, Egypt</li>
        </ul>
            </div>
</body>
</body>
</html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day2\resources\views/contactUs.blade.php ENDPATH**/ ?>