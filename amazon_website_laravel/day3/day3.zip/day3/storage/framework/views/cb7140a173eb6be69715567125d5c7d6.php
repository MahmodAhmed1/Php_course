<?php $__env->startSection("title", "create product"); ?>

<?php $__env->startSection("content"); ?>


<!-- <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?> -->
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Add</title>
    </head>
    <body>
    <div class="container">

    <h1> Add new product </h1>
    <form method="POST" action="<?php echo e(route('products.store')); ?>?track=php">
        <?php echo csrf_field(); ?>
        <div>
            <label  class="form-label">Name</label>
            <input type="text" name='name'class="form-control" value="<?php echo e(old('name')); ?>" ><br><br>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red; font-weight: bold;">
                <?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label  class="form-label">Price</label>
            <input type="text"  name='price' class="form-control" value="<?php echo e(old('price')); ?>" ><br><br>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red; font-weight: bold;">
                <?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label  class="form-label">Description</label>
            <input type="text" name="description" class="form-control" ><br><br>
        </div>
        <div class="form-group">
            <label for="Category" class="form-label">Category</label>
            <select id="Category" name="category_id">
                <option value="1">Electronics</option>
                <option value="2">Clothing, Shoes & Jewelry</option>
                <option value="3">Toys & Games</option>
                <option value="4">Grocery & Gourmet Food</option>
            </select>
            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: red; font-weight: bold;">
                <?php echo e($message); ?>

            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br><br>
        </div>

        
        <div>
        <label class="form-label">Image</label>
        <input type="file" name="image" class="form-control">
    </div><br>
        <button type="submit" class="submitButton">Submit</button>
     </form>

     </div>
     </body>
     </html>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/products/create.blade.php ENDPATH**/ ?>