<?php $__env->startSection("title", "edit product"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1> Edit product </h1>
        <form method="POST" action="<?php echo e(route('products.update', $product->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-3">
                <label  class="form-label">Name</label>
                <input type="text" name='name'class="form-control" value="<?php echo e($product->name); ?>" >
            </div>
            <div class="mb-3">
                <label  class="form-label">Price</label>
                <input type="text"  name='price' value="<?php echo e($product->price); ?>" class="form-control" >
            </div>
            <div class="mb-3">
                <label  class="form-label">Description</label>
                <input type="text" name="description" value="<?php echo e($product->description); ?>" class="form-control" >
            </div>
            <div class="mb-3">
                <label  class="form-label">Image</label>
                    <input type="file" name="image" class="form-control" value="<?php echo e($product->image); ?>"" >
            </div><br>
            <button type="submit" class="submitButton">Submit</button>
        </form>

    </div>
    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/products/edit.blade.php ENDPATH**/ ?>