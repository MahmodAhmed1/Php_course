<?php $__env->startSection("title", "home"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    <div class="container">
        <h1>Welcome to Amazon</h1>
        <p>This website is a shopping website for different products.</p>
    </div>
</body>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus quae nulla odit dignissimos nesciunt maxime sunt assumenda tempora velit. Illo natus similique laborum ex magni, architecto iure non minima voluptas.</p>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam, perferendis. Inventore fugit eveniet suscipit quibusdam accusamus! Repudiandae amet laudantium, modi voluptate quis, tempore impedit quia ipsam ex, nihil molestiae in.</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore quod libero at dolor, temporibus similique eius ab qui quis alias ipsam sint, explicabo ea exercitationem itaque laudantium amet? Libero, dolores!</p>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day2\resources\views/home.blade.php ENDPATH**/ ?>