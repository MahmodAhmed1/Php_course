
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

</head>
<body>
<header>
    <nav>
        <div class="logo">logo</div>
        <ul class="nav-items">
            <li><a href="<?php echo e(route("home")); ?>">Home</a></li>
            <li><a href="<?php echo e(route("about")); ?>">About Us</a></li>
            <li><a href="<?php echo e(route("contact")); ?>">contact Us</a></li>
            <li><a href="<?php echo e(route("products")); ?>">all Products</a></li>
        </ul>
    </nav>
</header>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day2\resources\views/layout/header.blade.php ENDPATH**/ ?>