<?php $__env->startSection("title", "Categories"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Amazon Categories</title>
    <style>
        .category-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .category-item {
            width: 80%;
            height: 400px;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            color: #29ad22;
            font-size: 40px;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
        }


        .category-item:hover {
            background-color: #f5f5f5;
            cursor: pointer;
        }

    </style>
</head>
<body>
    <h1 style="text-align: center">Amazon Categories</h1>
    <ul class="category-list">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="category-item" style="background-image: url('<?php echo e(asset($category->image)); ?>')">
            <a href="<?php echo e(route('categories/showProducts', ['category' => $category->id])); ?>"><?php echo e($category->name); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/categories/index.blade.php ENDPATH**/ ?>