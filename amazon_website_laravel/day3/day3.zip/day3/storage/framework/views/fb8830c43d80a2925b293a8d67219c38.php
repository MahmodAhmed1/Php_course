<?php $__env->startSection("title", "home"); ?>

<?php $__env->startSection("content"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<body>
    <div class="container">
        <h1>Welcome to Amazon</h1>
        <p>This website is a shopping website for different products.</p>
    </div>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/home.blade.php ENDPATH**/ ?>