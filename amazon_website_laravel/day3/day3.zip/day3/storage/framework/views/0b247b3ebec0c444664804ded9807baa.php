<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Font Awesome -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
        <!-- MDB -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.2.0/mdb.min.css" rel="stylesheet" />
        <!-- MDB -->

        <script src="main.js"></script>

        <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">

        <title><?php echo $__env->yieldContent('title', 'unknown page'); ?></title>
    </head>
    <body>
        <!-- Header -->
        <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end header -->

        <!-- body of page -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- end body -->

        <!-- footer -->
        
        <!-- end footer -->
    </body>

</html>
<?php /**PATH C:\xampp\htdocs\php-course\iti\laravel\day3\day3\resources\views/layout/master.blade.php ENDPATH**/ ?>