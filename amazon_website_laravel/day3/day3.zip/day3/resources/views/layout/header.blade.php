
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

</head>
<body>
<header>
    <nav>
        <a href="{{route("home")}}" style="font-size: 24px; font-weight: bold; text-decoration: none; color: #ffffff;">Amazon</a>
        <ul class="nav-items">
            <li><a href="{{route("home")}}">Home</a></li>
            <li><a href="{{route("about")}}">About Us</a></li>
            <li><a href="{{route("contact")}}">contact Us</a></li>
            <li><a href="{{route("categories")}}">Categories</a></li>
            <li><a href="{{route("products")}}">All Products</a></li>
        </ul>
    </nav>
</header>
</body>
</html>


